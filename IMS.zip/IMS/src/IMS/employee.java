//K.SAI PRASAD 1602-19-737-095 INSURANCE MANAGEMENT SYSTEM
package IMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class employee
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_employee_id,JL_employee_name,JL_employee_contact,JL_employee_address,JL_branch_code;
	private JTextField JTF_employee_id,JTF_employee_name,JTF_employee_contact,JTF_employee_address,JTF_branch_code;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert2,update2,view2,delete2;
	private List employeeList;
	private Choice branchCode;
	
	public employee(JPanel pn,JFrame jframe,JMenuItem insert2,JMenuItem update2,JMenuItem view2,JMenuItem delete2)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert2=insert2;
		this.update2=update2;
		this.view2=view2;
		this.delete2=delete2;
		
		JL_employee_id=new JLabel("employee_id:");
		JTF_employee_id=new JTextField(10);
		JL_employee_name=new JLabel("employee Name:");
		JTF_employee_name=new JTextField(10);
		JL_employee_contact=new JLabel("employee Contact:");
        JTF_employee_contact=new JTextField(10);
        JL_employee_address=new JLabel("employee Address:");
        JTF_employee_address=new JTextField(10);
        JL_branch_code=new JLabel("Branch Code:");
        branchCode=new Choice();
        JTF_branch_code=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737095","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadbranch()
	{
		try
		{
			//branchCode=new Choice();
			branchCode.removeAll();
			rs=stmt.executeQuery("select * from branch");
			while(rs.next()) 
			{
				branchCode.add(rs.getString("branch_code"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loademployee()
	{
		try
		{
			employeeList=new List();
			employeeList.removeAll();
			rs=stmt.executeQuery("select * from employee");
			while(rs.next()) 
			{
				employeeList.add(rs.getString("employee_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				loadbranch();
				
				JTF_employee_id.setText(null);
				JTF_employee_name.setText(null);
				JTF_employee_contact.setText(null);
				JTF_employee_address.setText(null);
				//JTF_branch_code.setText(null);
				
				loademployee();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_employee_id);
				pn1.add(JTF_employee_id);
				pn1.add(JL_employee_name);
				pn1.add(JTF_employee_name);
				pn1.add(JL_employee_contact);
				pn1.add(JTF_employee_contact);
				pn1.add(JL_employee_address);
				pn1.add(JTF_employee_address);
				pn1.add(JL_branch_code);
				pn1.add(branchCode);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				employeeList=new List(10);
				loademployee();
				pn2.add(employeeList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO employee VALUES(" + JTF_employee_id.getText() + ","
							+ "'" +JTF_employee_name.getText() +"'," +"'"+JTF_employee_contact.getText() +"'," + "'"+JTF_employee_address.getText() +"',"+"'"+branchCode.getSelectedItem()+"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loademployee();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_employee_id.setText(null);
				JTF_employee_name.setText(null);
				JTF_employee_contact.setText(null);
				JTF_employee_address.setText(null);
				JTF_branch_code.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_employee_id);
				pn1.add(JTF_employee_id);
				pn1.add(JL_employee_name);
				pn1.add(JTF_employee_name);
				pn1.add(JL_employee_contact);
				pn1.add(JTF_employee_contact);
				pn1.add(JL_employee_address);
				pn1.add(JTF_employee_address);
				pn1.add(JL_branch_code);
				pn1.add(JTF_branch_code);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				employeeList=new List(10);
				loademployee();
				pn2.add(employeeList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				employeeList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from employee");
							while (rs.next()) 
							{
								if (rs.getString("employee_id").equals(employeeList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_employee_id.setText(rs.getString("employee_id"));
								JTF_employee_name.setText(rs.getString("employee_name"));
								JTF_employee_contact.setText(rs.getString("employee_contact"));
								JTF_employee_address.setText(rs.getString("employee_address"));
								JTF_branch_code.setText(rs.getString("branch_code"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New employee Name:");
								JTF_employee_name.setText(pack);
								String query="update employee set employee_name='"+pack+"' where employee_id="+JTF_employee_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loademployee();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_employee_id.setText(null);
				JTF_employee_name.setText(null);
				JTF_employee_contact.setText(null);
				JTF_employee_address.setText(null);
				JTF_branch_code.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_employee_id);
				pn1.add(JTF_employee_id);
				pn1.add(JL_employee_name);
				pn1.add(JTF_employee_name);
				pn1.add(JL_employee_contact);
				pn1.add(JTF_employee_contact);
				pn1.add(JL_employee_address);
				pn1.add(JTF_employee_address);
				pn1.add(JL_branch_code);
				pn1.add(JTF_branch_code);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				employeeList=new List(10);
				loademployee();
				pn2.add(employeeList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				employeeList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from employee");
							while (rs.next()) 
							{
								if (rs.getString("employee_id").equals(employeeList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_employee_id.setText(rs.getString("employee_id"));
								JTF_employee_name.setText(rs.getString("employee_name"));
								JTF_employee_contact.setText(rs.getString("employee_contact"));
								JTF_employee_address.setText(rs.getString("employee_address"));
								JTF_branch_code.setText(rs.getString("branch_code"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM employee WHERE employee_id="+employeeList.getSelectedItem();
								String query="DELETE FROM employee WHERE employee_id="+JTF_employee_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loademployee();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("employee View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("employee Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("employee_id");
				        model.addColumn("employee name");
				        model.addColumn("employee contact");
				        model.addColumn("employee address");
				        model.addColumn("branch Code");
					    try 
					    {		
							rs=stmt.executeQuery("select * from employee");
							while(rs.next())
							{
								model.addRow(new Object[]{rs.getString("employee_id"), 
										rs.getString("employee_name"),rs.getString("employee_contact"),rs.getString("employee_address")
										,rs.getString("branch_code")});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
