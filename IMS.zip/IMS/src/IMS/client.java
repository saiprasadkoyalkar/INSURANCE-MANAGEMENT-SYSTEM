//K.SAI PRASAD 1602-19-737-095 INSURANCE MANAGEMENT SYSTEM
package IMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class client
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_client_id,JL_client_name,JL_client_contact,JL_client_address;
	private JTextField JTF_client_id,JTF_client_name,JTF_client_contact,JTF_client_address;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert3,update3,view3,delete3;
	private List clientList;
	
	public client(JPanel pn,JFrame jframe,JMenuItem insert3,JMenuItem update3,JMenuItem view3,JMenuItem delete3)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert3=insert3;
		this.update3=update3;
		this.view3=view3;
		this.delete3=delete3;
		
		JL_client_id=new JLabel("client_id:");
		JTF_client_id=new JTextField(10);
		JL_client_name=new JLabel("client Name:");
		JTF_client_name=new JTextField(10);
		JL_client_contact=new JLabel("Client Contact:");
        JTF_client_contact=new JTextField(10);
        JL_client_address=new JLabel("client Address:");
        JTF_client_address=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737095","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadclient()
	{
		try
		{
			clientList=new List();
			clientList.removeAll();
			rs=stmt.executeQuery("select * from client");
			while(rs.next()) 
			{
				clientList.add(rs.getString("client_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_client_id.setText(null);
				JTF_client_name.setText(null);
				JTF_client_contact.setText(null);
				JTF_client_address.setText(null);
				
				loadclient();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_client_id);
				pn1.add(JTF_client_id);
				pn1.add(JL_client_name);
				pn1.add(JTF_client_name);
				pn1.add(JL_client_contact);
				pn1.add(JTF_client_contact);
				pn1.add(JL_client_address);
				pn1.add(JTF_client_address);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				clientList=new List(10);
				loadclient();
				pn2.add(clientList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO client VALUES(" + JTF_client_id.getText() + ","
							+ "'" +JTF_client_name.getText() +"'," +"'"+JTF_client_contact.getText() +"'," + "'"+JTF_client_address.getText() +"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadclient();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_client_id.setText(null);
				JTF_client_name.setText(null);
				JTF_client_contact.setText(null);
				JTF_client_address.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_client_id);
				pn1.add(JTF_client_id);
				pn1.add(JL_client_name);
				pn1.add(JTF_client_name);
				pn1.add(JL_client_contact);
				pn1.add(JTF_client_contact);
				pn1.add(JL_client_address);
				pn1.add(JTF_client_address);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				clientList=new List(10);
				loadclient();
				pn2.add(clientList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				clientList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from client");
							while (rs.next()) 
							{
								if (rs.getString("client_id").equals(clientList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_client_id.setText(rs.getString("client_id"));
								JTF_client_name.setText(rs.getString("client_name"));
								JTF_client_contact.setText(rs.getString("client_contact"));
								JTF_client_address.setText(rs.getString("client_address"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New client Name:");
								JTF_client_name.setText(pack);
								String query="update client set client_name='"+pack+"' where client_id="+JTF_client_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadclient();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_client_id.setText(null);
				JTF_client_name.setText(null);
				JTF_client_contact.setText(null);
				JTF_client_address.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_client_id);
				pn1.add(JTF_client_id);
				pn1.add(JL_client_name);
				pn1.add(JTF_client_name);
				pn1.add(JL_client_contact);
				pn1.add(JTF_client_contact);
				pn1.add(JL_client_address);
				pn1.add(JTF_client_address);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				clientList=new List(10);
				loadclient();
				pn2.add(clientList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				clientList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from client");
							while (rs.next()) 
							{
								if (rs.getString("client_id").equals(clientList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_client_id.setText(rs.getString("client_id"));
								JTF_client_name.setText(rs.getString("client_name"));
								JTF_client_contact.setText(rs.getString("client_contact"));
								JTF_client_address.setText(rs.getString("client_address"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM client WHERE client_id="+clientList.getSelectedItem();
								String query="DELETE FROM client WHERE client_id="+JTF_client_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadclient();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("client View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("client Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("client_id");
				        model.addColumn("client name");
				        model.addColumn("client contact");
				        model.addColumn("client address");
					    try 
					    {		
							rs=stmt.executeQuery("select * from client");
							while(rs.next())
							{
								 model.addRow(new Object[]{rs.getInt(1), 
								 rs.getString(2),rs.getString(3),rs.getString(4)});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
