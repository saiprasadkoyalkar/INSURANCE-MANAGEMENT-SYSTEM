//K.SAI PRASAD 1602-19-737-095 INSURANCE MANAGEMENT SYSTEM
package IMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class insurance
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_insurance_num,JL_insurance_type,JL_client_id,JL_insurance_amount,JL_pay_per_month,JL_start_date,JL_end_date,JL_branch_code,JL_employee_id;
	private JTextField JTF_insurance_num,JTF_insurance_type,JTF_client_id,JTF_insurance_amount,JTF_pay_per_month,JTF_start_date,JTF_end_date,JTF_branch_code,JTF_employee_id;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert4,update4,view4,delete4;
	private List insuranceList;
	private Choice clientId,branchCode,employeeId;
	
	public insurance(JPanel pn,JFrame jframe,JMenuItem insert4,JMenuItem update4,JMenuItem view4,JMenuItem delete4)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert4=insert4;
		this.update4=update4;
		this.view4=view4;
		this.delete4=delete4;
		
		JL_insurance_num=new JLabel("insurance_num:");
		JTF_insurance_num=new JTextField(10);
		JL_insurance_type=new JLabel("insurance Name:");
		JTF_insurance_type=new JTextField(10);
		JL_client_id=new JLabel("Client Id:");
		clientId=new Choice();
        JTF_client_id=new JTextField(10);
		JL_insurance_amount=new JLabel("insurance Amount:");
        JTF_insurance_amount=new JTextField(10);
        JL_pay_per_month=new JLabel("Pay Per Month:");
        JTF_pay_per_month=new JTextField(10);
        JL_start_date=new JLabel("Start Date:");
        JTF_start_date=new JTextField(10);
        JL_end_date=new JLabel("End Date:");
        JTF_end_date=new JTextField(10);
        JL_branch_code=new JLabel("Branch Code:");
        branchCode=new Choice();
        JTF_branch_code=new JTextField(10);
        JL_employee_id=new JLabel("Employee Id:");
        employeeId=new Choice();
        JTF_employee_id=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737095","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadclient()
	{
		try
		{
			//clientId=new Choice();
			clientId.removeAll();
			rs=stmt.executeQuery("select * from client");
			while(rs.next()) 
			{
				clientId.add(rs.getString("client_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadbranch()
	{
		try
		{
			//branchCode=new Choice();
			branchCode.removeAll();
			rs=stmt.executeQuery("select * from branch");
			while(rs.next()) 
			{
				branchCode.add(rs.getString("branch_code"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loademployee()
	{
		try
		{
			//employeeId=new Choice();
			employeeId.removeAll();
			rs=stmt.executeQuery("select * from employee");
			while(rs.next()) 
			{
				employeeId.add(rs.getString("employee_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadinsurance()
	{
		try
		{
			insuranceList=new List();
			insuranceList.removeAll();
			rs=stmt.executeQuery("select * from insurance");
			while(rs.next()) 
			{
				insuranceList.add(rs.getString("insurance_num"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				loadclient();
				loadbranch();
				loademployee();
				loadinsurance();
				
				JTF_insurance_num.setText(null);
				JTF_insurance_type.setText(null);
				//JTF_client_id.setText(null);
				JTF_insurance_amount.setText(null);
				JTF_pay_per_month.setText(null);
				JTF_start_date.setText(null);
				JTF_end_date.setText(null);
				//JTF_branch_code.setText(null);
				//JTF_employee_id.setText(null);
				
				loadinsurance();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_insurance_num);
				pn1.add(JTF_insurance_num);
				pn1.add(JL_insurance_type);
				pn1.add(JTF_insurance_type);
				pn1.add(JL_client_id);
				pn1.add(clientId);
				pn1.add(JL_insurance_amount);
				pn1.add(JTF_insurance_amount);
				pn1.add(JL_pay_per_month);
				pn1.add(JTF_pay_per_month);
				pn1.add(JL_start_date);
				pn1.add(JTF_start_date);
				pn1.add(JL_end_date);
				pn1.add(JTF_end_date);
				pn1.add(JL_branch_code);
				pn1.add(branchCode);
				pn1.add(JL_employee_id);
				pn1.add(employeeId);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				insuranceList=new List(10);
				loadinsurance();
				pn2.add(insuranceList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO insurance VALUES(" + JTF_insurance_num.getText() + ","
							+ "'" +JTF_insurance_type.getText() +"',"+"'"+clientId.getSelectedItem()+"',"+JTF_insurance_amount.getText()+","+JTF_pay_per_month.getText()+","+JTF_start_date.getText()+","+JTF_end_date.getText()+","+"'"+branchCode.getSelectedItem()+"',"+"'"+employeeId.getSelectedItem()+"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadinsurance();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_insurance_num.setText(null);
				JTF_insurance_type.setText(null);
				JTF_client_id.setText(null);
				JTF_insurance_amount.setText(null);
				JTF_pay_per_month.setText(null);
				JTF_start_date.setText(null);
				JTF_end_date.setText(null);
				JTF_branch_code.setText(null);
				JTF_employee_id.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_insurance_num);
				pn1.add(JTF_insurance_num);
				pn1.add(JL_insurance_type);
				pn1.add(JTF_insurance_type);
				pn1.add(JL_client_id);
				pn1.add(JTF_client_id);
				pn1.add(JL_insurance_amount);
				pn1.add(JTF_insurance_amount);
				pn1.add(JL_pay_per_month);
				pn1.add(JTF_pay_per_month);
				pn1.add(JL_start_date);
				pn1.add(JTF_start_date);
				pn1.add(JL_end_date);
				pn1.add(JTF_end_date);
				pn1.add(JL_branch_code);
				pn1.add(JTF_branch_code);
				pn1.add(JL_employee_id);
				pn1.add(JTF_employee_id);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				insuranceList=new List(10);
				loadinsurance();
				pn2.add(insuranceList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				insuranceList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from insurance");
							while (rs.next()) 
							{
								if (rs.getString("insurance_num").equals(insuranceList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_insurance_num.setText(rs.getString("insurance_num"));
								JTF_insurance_type.setText(rs.getString("insurance_type"));
								JTF_client_id.setText(rs.getString("client_id"));
								JTF_insurance_amount.setText(rs.getString("insurance_amount"));
								JTF_pay_per_month.setText(rs.getString("pay_per_month"));
								JTF_start_date.setText(rs.getString("start_date"));
								JTF_end_date.setText(rs.getString("end_date"));
								JTF_branch_code.setText(rs.getString("branch_code"));
								JTF_employee_id.setText(rs.getString("employee_id"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New insurance Type:");
								JTF_insurance_type.setText(pack);
								String query="update insurance set insurance_type='"+pack+"' where insurance_num="+JTF_insurance_num.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadinsurance();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_insurance_num.setText(null);
				JTF_insurance_type.setText(null);
				JTF_client_id.setText(null);
				JTF_insurance_amount.setText(null);
				JTF_pay_per_month.setText(null);
				JTF_start_date.setText(null);
				JTF_end_date.setText(null);
				JTF_branch_code.setText(null);
				JTF_employee_id.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_insurance_num);
				pn1.add(JTF_insurance_num);
				pn1.add(JL_insurance_type);
				pn1.add(JTF_insurance_type);
				pn1.add(JL_client_id);
				pn1.add(JTF_client_id);
				pn1.add(JL_insurance_amount);
				pn1.add(JTF_insurance_amount);
				pn1.add(JL_pay_per_month);
				pn1.add(JTF_pay_per_month);
				pn1.add(JL_start_date);
				pn1.add(JTF_start_date);
				pn1.add(JL_end_date);
				pn1.add(JTF_end_date);
				pn1.add(JL_branch_code);
				pn1.add(JTF_branch_code);
				pn1.add(JL_employee_id);
				pn1.add(JTF_employee_id);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				insuranceList=new List(10);
				loadinsurance();
				pn2.add(insuranceList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				insuranceList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from insurance");
							while (rs.next()) 
							{
								if (rs.getString("insurance_num").equals(insuranceList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_insurance_num.setText(rs.getString("insurance_num"));
								JTF_insurance_type.setText(rs.getString("insurance_type"));
								JTF_client_id.setText(rs.getString("client_id"));
								JTF_insurance_amount.setText(rs.getString("insurance_amount"));
								JTF_pay_per_month.setText(rs.getString("pay_per_month"));
								JTF_start_date.setText(rs.getString("start_date"));
								JTF_end_date.setText(rs.getString("end_date"));
								JTF_branch_code.setText(rs.getString("branch_code"));
								JTF_employee_id.setText(rs.getString("employee_id"));
								
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM insurance WHERE insurance_num="+insuranceList.getSelectedItem();
								String query="DELETE FROM insurance WHERE insurance_num="+JTF_insurance_num.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadinsurance();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("insurance View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("insurance Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("insurance_num");
				        model.addColumn("insurance type");
				        model.addColumn("Client Id");
				        model.addColumn("insurance amount");
				        model.addColumn("Pay per month");
				        model.addColumn("Start day");
				        model.addColumn("End day");
				        model.addColumn("branch Code");
				        model.addColumn("Employee Id");
					    try 
					    {		
							rs=stmt.executeQuery("select * from insurance");
							while(rs.next())
							{
								model.addRow(new Object[]{rs.getString("insurance_num"), 
										rs.getString("insurance_type"),rs.getString("client_id"),rs.getString("insurance_amount"),rs.getString("pay_per_month")
										,rs.getString("start_date"),rs.getString("end_date"),rs.getString("branch_code"),rs.getString("employee_id")});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
