package IMS;
import java.awt.*;
import javax.swing.*;
public class IMSUI extends JFrame
{
	private JPanel Jpn0,Jpn1;
    private JMenuBar mbar;
    private JMenu branch,employee,client,insurance,payment;
    private JMenuItem insert1,update1,view1,delete1;
    private JMenuItem insert2,update2,view2,delete2;
    private JMenuItem insert3,update3,view3,delete3;
    private JMenuItem insert4,update4,view4,delete4;
    private JMenuItem insert5,update5,view5,delete5;
    /*private JMenuItem insert6,update6,view6,delete6;
    private JMenuItem s1,s2,s3,s4,s5;*/

    private JLabel labelName;
    
    public void defineComponents()
    {
    	Jpn0=new JPanel();
    	Jpn1=new JPanel();
    	
    	mbar=new JMenuBar();
    	
    	//statesAvailable=new JMenu("List Of States Available");//d_1
    	branch=new JMenu("Branch");
    	employee=new JMenu("Employee");
    	client=new JMenu("Client");
    	insurance=new JMenu("Insurance");
    	payment=new JMenu("Payment");
    	
    	labelName=new JLabel("Insurance Management System"); 	
    }
    public void addComponents()
    {
    	add(Jpn0);
    	Jpn1.add(labelName);
    	Jpn1.setAlignmentY(CENTER_ALIGNMENT);
    	Jpn1.setBounds(500,500,800,100);
    	Jpn0.add(Jpn1);
    	
    	setJMenuBar(mbar);
    	
    	mbar.add(branch);
    	mbar.add(employee);
    	mbar.add(client);
    	mbar.add(insurance);
    	mbar.add(payment);
    	
    	/*statesAvailable.add(s1=new JMenuItem("Goa"));
    	statesAvailable.add(s2=new JMenuItem("Kerala"));
    	statesAvailable.add(s3=new JMenuItem("Telangana"));
    	statesAvailable.add(s4=new JMenuItem("Maharashtra"));
    	statesAvailable.add(s5=new JMenuItem("Uttar Pradesh"));*/

    	branch.add(insert1=new JMenuItem("Insert"));
    	branch.add(update1=new JMenuItem("Update"));
    	branch.add(view1=new JMenuItem("View"));
    	branch.add(delete1=new JMenuItem("Delete"));
    	
    	employee.add(insert2=new JMenuItem("Insert"));
    	employee.add(update2=new JMenuItem("Update"));
    	employee.add(view2=new JMenuItem("View"));
    	employee.add(delete2=new JMenuItem("Delete"));
    	
    	client.add(insert3=new JMenuItem("Insert"));
    	client.add(update3=new JMenuItem("Update"));
    	client.add(view3=new JMenuItem("View"));
    	client.add(delete3=new JMenuItem("Delete"));
    	
    	insurance.add(insert4=new JMenuItem("Insert"));
    	insurance.add(update4=new JMenuItem("Update"));
    	insurance.add(view4=new JMenuItem("View"));
    	insurance.add(delete4=new JMenuItem("Delete"));
    	
    	payment.add(insert5=new JMenuItem("Insert"));
    	payment.add(update5=new JMenuItem("Update"));
    	payment.add(view5=new JMenuItem("View"));
    	payment.add(delete5=new JMenuItem("Delete"));

    }
    public void registerComponents()
    {
    	branch obj_branch=new branch(Jpn0,IMSUI.this,insert1,update1,view1,delete1);
    	obj_branch.buildGUI();
    	employee obj_employee=new employee(Jpn0,IMSUI.this,insert2,update2,view2,delete2);
    	obj_employee.buildGUI();
    	client obj_client=new client(Jpn0,IMSUI.this,insert3,update3,view3,delete3);
    	obj_client.buildGUI();
    	insurance obj_insurance=new insurance(Jpn0,IMSUI.this,insert4,update4,view4,delete4);
    	obj_insurance.buildGUI();
    	payment obj_payment=new payment(Jpn0,IMSUI.this,insert5,update5,view5,delete5);
    	obj_payment.buildGUI();
    }
	public IMSUI()
	{
		defineComponents();
		addComponents();
		registerComponents();
		setSize(400,500);
		setBackground(Color.GRAY);
		setVisible(true);
		setTitle("INSURANCE MANAGEMENT SYSTEM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
