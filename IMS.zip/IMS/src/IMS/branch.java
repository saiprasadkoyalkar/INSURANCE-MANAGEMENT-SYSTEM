//K.SAI PRASAD 1602-19-737-095 INSURANCE MANAGEMENT SYSTEM
package IMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class branch
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_branch_code,JL_branch_name,JL_branch_address;
	private JTextField JTF_branch_code,JTF_branch_name,JTF_branch_address;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert1,update1,view1,delete1;
	private List branchList;
	
	public branch(JPanel pn,JFrame jframe,JMenuItem insert1,JMenuItem update1,JMenuItem view1,JMenuItem delete1)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert1=insert1;
		this.update1=update1;
		this.view1=view1;
		this.delete1=delete1;
		
		JL_branch_code=new JLabel("Branch_Code:");
		JTF_branch_code=new JTextField(10);
		JL_branch_name=new JLabel("Branch Name:");
		JTF_branch_name=new JTextField(10);
        JL_branch_address=new JLabel("Branch Address:");
        JTF_branch_address=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737095","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadbranch()
	{
		try
		{
			branchList=new List();
			branchList.removeAll();
			rs=stmt.executeQuery("select * from branch");
			while(rs.next()) 
			{
				branchList.add(rs.getString("branch_code"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_branch_code.setText(null);
				JTF_branch_name.setText(null);
				JTF_branch_address.setText(null);
				
				loadbranch();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_branch_code);
				pn1.add(JTF_branch_code);
				pn1.add(JL_branch_name);
				pn1.add(JTF_branch_name);
				pn1.add(JL_branch_address);
				pn1.add(JTF_branch_address);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				branchList=new List(10);
				loadbranch();
				pn2.add(branchList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO branch VALUES(" + JTF_branch_code.getText() + ","
							+ "'" +JTF_branch_name.getText() +"'," + "'"+JTF_branch_address.getText() +"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadbranch();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_branch_code.setText(null);
				JTF_branch_name.setText(null);
				JTF_branch_address.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_branch_code);
				pn1.add(JTF_branch_code);
				pn1.add(JL_branch_name);
				pn1.add(JTF_branch_name);
				pn1.add(JL_branch_address);
				pn1.add(JTF_branch_address);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				branchList=new List(10);
				loadbranch();
				pn2.add(branchList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				branchList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from branch");
							while (rs.next()) 
							{
								if (rs.getString("branch_code").equals(branchList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_branch_code.setText(rs.getString("branch_code"));
								JTF_branch_name.setText(rs.getString("branch_name"));
								JTF_branch_address.setText(rs.getString("branch_address"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New Branch Name:");
								JTF_branch_name.setText(pack);
								String query="update branch set branch_name='"+pack+"' where branch_code="+JTF_branch_code.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadbranch();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_branch_code.setText(null);
				JTF_branch_name.setText(null);
				JTF_branch_address.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_branch_code);
				pn1.add(JTF_branch_code);
				pn1.add(JL_branch_name);
				pn1.add(JTF_branch_name);
				pn1.add(JL_branch_address);
				pn1.add(JTF_branch_address);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				branchList=new List(10);
				loadbranch();
				pn2.add(branchList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				branchList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from branch");
							while (rs.next()) 
							{
								if (rs.getString("branch_code").equals(branchList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_branch_code.setText(rs.getString("branch_code"));
								JTF_branch_name.setText(rs.getString("branch_name"));
								JTF_branch_address.setText(rs.getString("branch_address"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM branch WHERE branch_code="+branchList.getSelectedItem();
								String query="DELETE FROM branch WHERE branch_code="+JTF_branch_code.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadbranch();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("Branch View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("Branch Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("branch_code");
				        model.addColumn("branch name");
				        model.addColumn("branch address");
					    try 
					    {		
							rs=stmt.executeQuery("select * from branch");
							while(rs.next())
							{
								 model.addRow(new Object[]{rs.getInt(1), 
								 rs.getString(2),rs.getString(3)});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
